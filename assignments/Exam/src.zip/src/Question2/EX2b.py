import scipy.stats

print(scipy.stats.binom.ppf(0.025, 20, 0.5))
print(scipy.stats.binom.ppf(0.975, 20, 0.5))